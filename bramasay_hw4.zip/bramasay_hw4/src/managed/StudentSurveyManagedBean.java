package managed;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;

import bean.WinningResult;
import entity.Studsurveyinfo;
import processor.DataProcessor;
import session.StudentSurveySessionBean;

/**
 * This class is a POJO class in which all the student details are present
 *
 * 
 * @author Bhavana Ramasayam
 */

@ManagedBean(name = "studentSurvey")
@SessionScoped
public class StudentSurveyManagedBean implements Serializable {

	private StudentSurveySessionBean studentSurveySessionBean = new StudentSurveySessionBean();
	

	private List<StudentSurveyManagedBean> studentSurveyManagedBeans;
	private WinningResult winningResult;

	private long studentid;
	private String firstname;
	private String lastname;
	private String streetaddress;
	private String zipcode;
	private String city;
	private String sstate;
	private String telnum;
	private String email;
	// private String surveydate;
	private Date surveydate;
	private Date possStartDateOfSem;
	private String likings;
	private String[] campusLike;
	private String interest;
	private String recomend;
	private String addComm;
	/*
	 * private String ename1; private String etel1; private String eemail1;
	 * private String ename2; private String etel2; private String eemail2;
	 */
	private String raffle;

	private final String schoolRecommendString = "Very Likely,Likely,Unlikely";
	private final String[] schoolRecommendArray = schoolRecommendString.split(",");

	public String resetSessionNRedirect(String nextPage) {
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("studentSurvey", null);

		return nextPage;
	}

	/**
	 *
	 * @return
	 */
	public String saveStudentSurveyInfo() {
		String fwdToXhtml = null;
		boolean isSaveSuccess = false;
		FacesContext facesContext = FacesContext.getCurrentInstance();

		if (getPossStartDateOfSem().before(getSurveydate())) {
			FacesMessage errorMessage = new FacesMessage("Semester start date must be after survey date");

			errorMessage.setSeverity(FacesMessage.SEVERITY_ERROR);
			facesContext.addMessage("form1:possStartDateOfSem", errorMessage);
		} else {
			
		
		Studsurveyinfo studsurveyinfo = new Studsurveyinfo();

		studsurveyinfo.setFirstname(firstname);
		studsurveyinfo.setLastname(lastname);
		studsurveyinfo.setStreetaddress(streetaddress);
		studsurveyinfo.setZipcode(zipcode);
		studsurveyinfo.setCity(city);
		studsurveyinfo.setSstate(sstate);
		studsurveyinfo.setTelnum(telnum);
		studsurveyinfo.setEmail(email);
		studsurveyinfo.setSurveydate(surveydate);
		studsurveyinfo.setInterest(interest);
		studsurveyinfo.setRecomend(recomend);
		studsurveyinfo.setAddComm(addComm);

		StringBuilder like = new StringBuilder();
		for (String campusLikeVal : campusLike) {
			like.append(campusLikeVal);
			like.append(" ");
		}
		studsurveyinfo.setLikings(like.toString());

		
		System.out.println("studsurveyinfo" + studsurveyinfo);
		isSaveSuccess = studentSurveySessionBean.saveStudentSurveyInfo(studsurveyinfo);
		}
		if (isSaveSuccess) {
			WinningResult result = DataProcessor.calculateMeanStandardDeviation(raffle);
			setWinningResult(result);

			if (null != result && result.getMean() > 90) {
				// WinnerAcknowledgement JSP
				fwdToXhtml = "winnerAcknowledgement";
			} else {
				// SimpleAcknowledgement JSP
				fwdToXhtml = "simpleAcknowledgement";
			}
		} else {
			fwdToXhtml = "errorPage";
		}

		return fwdToXhtml;
	}

	public List<StudentSurveyManagedBean> retireveStudentSurveyInfo() {
		List<Studsurveyinfo> studsurveyinfos = studentSurveySessionBean.retrieveStudentSurveyInfo();

		return setStudentSurveyDetails(studsurveyinfos);
	}

	public String searchStudentSurveyInfo() {
		Studsurveyinfo studsurveyinfo = new Studsurveyinfo();
		boolean doSearch = false;

		if (!StringUtils.EMPTY.equalsIgnoreCase(firstname)) {
			studsurveyinfo.setFirstname(firstname);
			doSearch = true;
		}
		if (!StringUtils.EMPTY.equalsIgnoreCase(lastname)) {
			studsurveyinfo.setLastname(lastname);
			doSearch = true;
		}
		if (!StringUtils.EMPTY.equalsIgnoreCase(sstate)) {
			studsurveyinfo.setSstate(sstate);
			doSearch = true;
		}
		if (!StringUtils.EMPTY.equalsIgnoreCase(city)) {
			studsurveyinfo.setCity(city);
			doSearch = true;
		}
		doSearch = true;
		if (doSearch) {
			
			List<Studsurveyinfo> studsurveyinfos = studentSurveySessionBean.searchStudentSurveyInfo(studsurveyinfo);
			setStudentSurveyManagedBeans(setStudentSurveyDetails(studsurveyinfos));
		}

		return "searchStudentSurvey";
	}

	public String deleteStudentSurveyInfo(int studentId, String isSearch) {
		String fwdToXhtml = null;
		if (!studentSurveySessionBean.deleteStudentSurveyInfo(studentId)) {
			fwdToXhtml = "error";
		} else {
			if (StringUtils.equalsIgnoreCase("YES", isSearch)) {
				searchStudentSurveyInfo();
			} else {
				retireveStudentSurveyInfo();
			}
		}

		return fwdToXhtml;
	}

	public List<StudentSurveyManagedBean> setStudentSurveyDetails(List<Studsurveyinfo> studsurveyinfos) {
		List<StudentSurveyManagedBean> studSurMangBeanList = new ArrayList<StudentSurveyManagedBean>();
		StudentSurveyManagedBean managedBean = null;

		if (null != studsurveyinfos) {
			for (Studsurveyinfo studsurveyinfo : studsurveyinfos) {
				managedBean = new StudentSurveyManagedBean();

				managedBean.setStudentid(studsurveyinfo.getStudentid());
				managedBean.setFirstname(studsurveyinfo.getFirstname());
				managedBean.setLastname(studsurveyinfo.getLastname());
				managedBean.setStreetaddress(studsurveyinfo.getStreetaddress());
				managedBean.setZipcode(studsurveyinfo.getZipcode());
				managedBean.setCity(studsurveyinfo.getCity());
				managedBean.setSstate(studsurveyinfo.getSstate());
				managedBean.setTelnum(studsurveyinfo.getTelnum());
				managedBean.setEmail(studsurveyinfo.getEmail());
				managedBean.setSurveydate(studsurveyinfo.getSurveydate());
				managedBean.setTelnum(studsurveyinfo.getTelnum());
				managedBean.setLikings(studsurveyinfo.getLikings());
				managedBean.setInterest(studsurveyinfo.getInterest());
				managedBean.setRecomend(studsurveyinfo.getRecomend());
				managedBean.setAddComm(studsurveyinfo.getAddComm());

				studSurMangBeanList.add(managedBean);
			}
		}

		return studSurMangBeanList;
	}

	public void setStudentSurveyManagedBeans(List<StudentSurveyManagedBean> studentSurveyManagedBeans) {
		this.studentSurveyManagedBeans = studentSurveyManagedBeans;
	}

	public List<StudentSurveyManagedBean> getStudentSurveyManagedBeans() {
		return studentSurveyManagedBeans;
	}

	public WinningResult getWinningResult() {
		return winningResult;
	}

	public long getStudentid() {
		return studentid;
	}

	public String getFirstname() {
		return firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public String getStreetaddress() {
		return streetaddress;
	}

	public String getZipcode() {
		return zipcode;
	}

	public String getCity() {
		return city;
	}

	public String getSstate() {
		return sstate;
	}

	public String getTelnum() {
		return telnum;
	}

	public String getEmail() {
		return email;
	}

	// public String getSurveydate() {
	// return surveydate;
	// }

	public Date getSurveydate() {
		return surveydate;
	}

	public Date getPossStartDateOfSem() {
		return possStartDateOfSem;
	}

	public String getLikings() {
		return likings;
	}

	public String[] getCampusLike() {
		return campusLike;
	}

	public String getInterest() {
		return interest;
	}

	public String getRecomend() {
		return recomend;
	}

	public void setWinningResult(WinningResult winningResult) {
		this.winningResult = winningResult;
	}

	public void setStudentid(long studentid) {
		this.studentid = studentid;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public void setStreetaddress(String streetaddress) {
		this.streetaddress = streetaddress;
	}

	public void setZipcode(String zipcode) {
		
		this.zipcode=zipcode;
		System.out.println("zipcode:"+zipcode);
    	Client client = ClientBuilder.newClient();
    	
        WebTarget target = client.target("http://localhost:8080/SWE645-Assignment4/webresources/zips/");
        WebTarget resourceWebTarget;
        resourceWebTarget = target.path(this.zipcode);
        
       
        Invocation.Builder invocationBuilder;
        invocationBuilder = resourceWebTarget.request(MediaType.TEXT_PLAIN);
        System.out.println(resourceWebTarget.getUri());
        Response response = invocationBuilder.get();
        System.out.println(response.getStatus());
        
        String s = response.readEntity(String.class);
        System.out.println("City"+s.split("-")[0]);
        System.out.println("State"+s.split("-")[1]);
        setCity(s.split("-")[0]);
        setSstate(s.split("-")[1]);
        
		/*if (null != zipcode) {
			if (zipcode.length() == 5) {
				for (Map.Entry<String, String> entry : getZipCityStateMap().entrySet()) {
					if (entry.getKey().equals(zipcode)) {
						String[] cityState = entry.getValue().split("-");
						city = cityState[0];
						sstate = cityState[1];
						break;
					} else {
						city = "";
						sstate = "";
					}
				}
			}
		}
		this.zipcode = zipcode;
	}

	public Map<String, String> getZipCityStateMap() {
		Map<String, String> zipCityState = new HashMap<String, String>();
		zipCityState.put("22312", "Alexandria-VA");
		zipCityState.put("22030", "Fairfax-VA");
		zipCityState.put("22301", "Tysons Corner-MD");
		zipCityState.put("20148", "Ashburn-VA");

		return zipCityState;*/
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setSstate(String sstate) {
		this.sstate = sstate;
	}

	public void setTelnum(String telnum) {
		this.telnum = telnum;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	// public void setSurveydate(String surveydate) {
	// this.surveydate = surveydate;
	// }

	public void setSurveydate(Date surveydate) {
		this.surveydate = surveydate;
	}

	public void setPossStartDateOfSem(Date possStartDateOfSem) {
		this.possStartDateOfSem = possStartDateOfSem;
	}

	public void setLikings(String likings) {
		this.likings = likings;
	}

	public void setCampusLike(String[] campusLike) {
		this.campusLike = campusLike;
	}

	public void setInterest(String interest) {
		this.interest = interest;
	}

	public void setRecomend(String recomend) {
		this.recomend = recomend;
	}

	public String getRaffle() {
		return raffle;
	}

	public void setRaffle(String raffle) {
		this.raffle = raffle;
	}

	public String getAddComm() {
		return addComm;
	}

	public void setAddComm(String addComm) {
		this.addComm = addComm;
	}

	public List<String> completeRecommend(String recommendPrefix) {
		List<String> matches = new ArrayList<String>();
		for (String possibleRecommend : schoolRecommendArray) {
			if (possibleRecommend.toUpperCase().startsWith(recommendPrefix.toUpperCase())) {
				matches.add(possibleRecommend);
			}
		}
		return (matches);
	}

}
